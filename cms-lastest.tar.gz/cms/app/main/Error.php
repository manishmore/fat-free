<?php
namespace main;

class Error {

    function get_show() {
        $num = (int)\F3::scrub(\F3::get('PARAMS.param'));
        \F3::set('error_num', $num);
        $arr = $this->errorArray();
        if ($num == '0') {
                \F3::reroute('/main/user/login');
			   }
        \F3::set('error_text', $arr[$num]);
        
        \F3::set('template', 'error');
    }
    /**
     * 
     */
    function errorArray() {
						
      $errorArr = array('Login again',
            'User Name or Email must be Unique',
        );
        return $errorArr;
    }

}

?>
